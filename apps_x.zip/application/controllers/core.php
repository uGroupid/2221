<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Core extends REST_Controller {
	function __construct(){
		parent::__construct();
		// $this->load->model('reset_model','ResetMD');
		$this->response = array('result'=>null);
		$this->ValueColumn = array();
	}
	public function dnsAccount_get(){
		$this->ValueColumn = array('username','user_domain','email','phone','status','auth','create_date','update_date','id_reseller');
		$this->response = array(
			'result' => App::GetDNSAccountAll($this->ValueColumn),
		);
		$this->response($this->response);
	}

	
	
}


class App extends MY_Controller{
	function __construct(){
		parent::__construct();
		$this->response = array();
	}
	public function GetDNSAccountAll($array = null){
		try{
			if(is_array($array)){
				$this->response = $this->mongo_db->select($array)->get('ureg_users');
			}else{
				$this->response = $this->mongo_db->select($array)->get('ureg_users');
			}
			return $this->response;
		}catch (Exception $e) {
			return false;
		}
	}
}

