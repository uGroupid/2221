<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Visa extends REST_Controller {
	function __construct(){
		parent::__construct();	
		$this->load->model('global_model', 'GlobalMD');	
		$this->load->model('visa_model', 'VisaMD');	
		$this->responses = $this->load_missing();
		$this->uid = null;
		$this->access_token = null;
		$this->token_exprice = $this->load_error_expired_token();
		
	
	}
	public function index_get(){
		$this->responses = array($this->GlobalMD->msg());
		$this->response($this->responses);
	}
	public function index_post(){
		$this->responses =  array($this->GlobalMD->msg());
		$this->response($this->responses);
	}
	public function load_missing(){
		return $this->responses = $this->GlobalMD->msg(2001);
		
	}
	private function load_error_expired_token(){
		return array('msg' => $this->GlobalMD->msg(2201));
	}
	private function get_id_access_token($access_token){
		$user = $this->GlobalMD->decode($this->access_token);
		if(isset($user->uid)){
			if(!empty($user->uid)){
				return $this->uid = $user->uid;
			}
		}
	}

	public function addx_get(){
		if(!empty($_GET['param'])){
			$param = $_GET['param'];
			$x = json_decode($param); 
			$this->responses = array(
				'responses' => array(
					'message' => $this->GlobalMD->msg(1000),
					'result' => array(
					'data' => array(
						'response' => $this->VisaMD->add($x),  
						// 'x'	=> $x->sesion_id,
					),),
				),
			);
		}
		$this->response($this->responses);
	}
	

	
	
}
?>