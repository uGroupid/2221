<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Client extends REST_Controller {
	public $responses;
	public $access_token;
	public $uid;
	public $keys;
	public $token_validate;
	public $contact_id;
	public $contact_default;
	public $contact_owner;
	public $contact_tech;
	public $contact_admin;
	public $contact_bill;
	public $username ;
	public $passwords;
	public $email;
	/////////////////////////////////
	public $street;
	public $zip;
	public $city;
	public $state;
	public $country;
	public $telephone;
	public $mobile;
	public $fax;
	//////////////////////////////////
	public $company_name;
	public $vat_id;
	public $customer_no;
	public $contact_name;
	public $language;
	public $usertheme;
	public $notes;
	public $created_at;
	public $response;
	//////////////////////////////////
	function __construct(){
		parent::__construct();
		$this->load->model('global_model', 'GlobalMD');	
		$this->load->model('core_model', 'QueryCoreMD');	
		$this->responses = $this->load_missing();
		$this->contact_id = null;
		$this->uid = null;
		$this->contact_default = null;
		$this->contact_owner = null;
		$this->contact_tech = null;
		$this->contact_admin = null;
		$this->contact_bill = null;
		$this->access_token = false;
		$this->token_validate = 'false';
	}
	public function index_get(){
		$this->responses = array($this->GlobalMD->msg());
		$this->response($this->responses);
	}
	public function index_post(){
		$this->responses =  array($this->GlobalMD->msg());
		$this->response($this->responses);
	}
	public function load_missing(){
		return $this->responses = $this->GlobalMD->msg(2001);
		
	}
	private function load_error_expired_token(){
		return array('msg' => $this->GlobalMD->msg(2201));
	}
	private function get_id_access_token($access_token){
		$user = $this->GlobalMD->decode($this->access_token);
		if(isset($user->uid)){
			if(!empty($user->uid)){
				return $this->uid = $user->uid;
			}
		}
	}
	public function contact_suppend(){
		
	}
	public function contact_remove(){
		
	}
	public function info_post(){
		if(isset($_POST)){
			if(!empty($_POST)){
				if(isset($_POST['access_token'])){
					if(!empty($_POST['access_token'])){
						$this->access_token = $_POST['access_token'];
						$check_access_token = $this->GlobalMD->validate($this->access_token);
						if($check_access_token==true){
							if(isset($_POST['param'])){
								$params = $_POST['param'];
								$x = json_decode($params);
								if(isset($x->uid)){
									if(!empty($x->uid)){
										$ClientsInfo = $this->QueryCoreMD->query_info_uid_clients($x->uid);
										if($ClientsInfo==true){
											if(!empty($ClientsInfo)){
											  $this->responses = $ClientsInfo;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		$this->response($this->responses);
	}	
	public function update_account_post(){
		if(isset($_POST['access_token'])){
			if(!empty($_POST['access_token'])){
				$this->access_token = $_POST['access_token'];
				$check_access_token = $this->GlobalMD->validate($this->access_token);
				if($check_access_token==true){
					if(isset($_POST['param'])){
						$x = $_POST['param'];
						$update = $this->QueryCoreMD->query_update_profile_account($x);
						if(isset($update) || !empty($update)){ $this->responses =  true; }else{ $this->responses =  false; }
					}
				}
			}
		}
		$this->response($this->responses);
	}

	public function add_post(){
		if(isset($_POST)){
			if(!empty($_POST)){
				if(isset($_POST['access_token'])){
					if(!empty($_POST['access_token'])){
						$this->access_token = $_POST['access_token'];
						$check_access_token = $this->GlobalMD->validate($this->access_token);
						if($check_access_token==true){
							if(isset($_POST['param'])){
								$params = $_POST['param'];
								$x = json_decode($params);
								if(isset($x->email)){
									if(!empty($x->email)){
										$check_client = $this->QueryCoreMD->query_check_client($x->email);
										if($check_client['code'] == 3001){
											$QueryInstall = $this->QueryCoreMD->query_client_creation($x);
											if($QueryInstall['code']==3003){
												$this->email_send($x);
												$this->responses = $QueryInstall;
											}else{
												$this->responses = $QueryInstall;
											}
										}else{
											$this->responses = $check_client;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		$this->response($this->responses);
	}
	private function email_send($x){
		$body = $this->body_email_active($x);
		$param = array(
			'title' => 'Account activation uGroup Member',
			'body' => $body,
			'email_from' => 'activation@ugroup.asia',
			'name_form' => 'uGroup Center Account Member',
			'name_to' => $x->full_name,
			'email_to' => $x->email,
			'date_query' => date("y-m-d H:i:s",time()),
			'date_send' => null,
			'status' => 1,
		);
		$this->mongo_db->insert('monitor_email',$param);
	}
	
	private function body_email_active($x){
		$string = json_encode($x);
		$activation = core_encode($string);
		$temp = '<h1>Dear! '.$x->full_name.' </h1>
		<p>You have registered an account at https://member.ugroup.asia below is the information you just registered. Be sure to click the validate account to use our services. Please do not reply with this message</p>
		</br>
		<h2>Registered account information:</h2>
		<table> 
			<tr><td>Full Name</td><td>'.$x->full_name.'</td></tr>
			<tr><td>Email Registered</td><td>'.$x->email.'</td></tr>
			<tr><td>Password Registered</td><td>'.$x->password.'</td></tr>
			<tr><td>Link Account Authentication</td><td><a target="_blank" title="Active Account uGroup Member" href="http://member.ugroup.asia/activation?token='.$activation.'">Click Here Active Account<a/></td></tr>
			<tr><td>Show Link Authentication</td><td>http://member.ugroup.asia/activation?token='.$activation.'</td></tr>
		</table>
		<h3>Best regards,</h3>
		<h5>uGroup Member Center</h5>
		<hr>
		<ul style="list-style: none;margin-left: -50px;"> 
			<li>Support Center Information:</li>
			<li><h1>uGroup Incorporated (tm),</h1></li>
			<li>Headquater: 51 Scotts Road, #02-06, Singapore, SGP 16819</li>			
			<li>Vietnam Office: Phu Dong Thien Vuong, Hai Ba Trung District, Hanoi, Vietnam 100000</li>
			<li>Phone Support Center: (+84)123-77-11-777 or (+84) 123-77-44-777</li>
			<li>Email Support Center: support@ugroup.asia</li>
			<li>Website: http://Member.uGroup.asia; Copyrigth uGroup(tm) - www.ugroup.asia</li>
		</ul>
		<hr>
		';
		$temp .='<h1>Kính Gửi! '.$x->full_name.'</h1>
		<p>Quý khách vừa đăng ký tài khoản trên https://member.ugroup.asia sau đây là những thông tin tài khoản Quý Khách vừa đăng ký. Hãy chác chắn là bạn đã ấn vào đường dẫn kích hoạt tài khoản để sử dụng các dịch vụ của chúng tôi. Vui lòng không trả lời lại e-Mail này</p>
		</br>
		<h2>Thông tin tài khoản của Quý Khách:</h2>
		<table> 
			<tr><td>Họ Tên</td><td>'.$x->full_name.'</td></tr>
			<tr><td>e-Mail Đã Đăng Ký</td><td>'.$x->email.'</td></tr>
			<tr><td>Mật Khẩu Đã Đăng Ký</td><td>'.$x->password.'</td></tr>
			<tr><td>Đường Dẫn Kích Hoạt</td><td><a target="_blank" title="Active Account uGroup Member" href="http://member.ugroup.asia/activation?token='.$activation.'">Ân vào đây để kích hoạt<a/></td></tr>
			<tr><td>Hiển Thị Đường Dẫn</td><td>http://member.ugroup.asia/activation?token='.$activation.'</td></tr>
		</table>
		<h3>Trân Trọng Cảm Ơn,</h3>
		<h5>uGroup Member Center</h5>
		<hr>
		<ul style="list-style: none;margin-left: -50px;"> 
			<li>Thông Tin Trung Tâm Hỗ Trợ:</li>
			<li><h1>uGroup Incorporated (tm),</h1></li>
			<li>Chụ Sở: 51 Scotts Road, #02-06, Singapore, SGP 16819</li>			
			<li>VP Việt Nam: Phu Dong Thien Vuong, Hai Ba Trung District, Hanoi, Vietnam 100000</li>
			<li>Hotline Support Center: (+84)123-77-11-777 or (+84) 123-77-44-777</li>
			<li>Email Support Center: support@ugroup.asia</li>
			<li>Website: http://Member.uGroup.asia; Copyrigth uGroup(tm) - www.ugroup.asia</li>
		</ul>
		</hr>
		';
		return core_encode(json_encode($temp));
	}
	public function contact_add_post(){
		if(isset($_POST)){
			if(!empty($_POST)){
				if(isset($_POST['access_token'])){
					if(!empty($_POST['access_token'])){
						$this->access_token = $_POST['access_token'];
						$check_access_token = $this->GlobalMD->validate($this->access_token);
						if($check_access_token==true){
							if(isset($_POST['param'])){
								$params = $_POST['param'];
								$x = json_decode($params);
								
							}
						}
					}
				}
			}
		}
		$this->response($this->responses);
	}
	public function contact_info_get(){
		if(isset($_GET)){
			if(!empty($_GET)){
				if(isset($_GET['access_token'])){
					if(!empty($_GET['access_token'])){
						$this->access_token = $_GET['access_token'];
						$check_access_token = $this->GlobalMD->validate($this->access_token);
						if($check_access_token==true){
							if(isset($_GET['param'])){
								if(!empty($_GET['param'])){
									$params = $_GET['param'];
									$x = json_decode($params);
									if(isset($x->contact_id)){
										if(!empty($x->contact_id)){
											$this->contact_id = $x->contact_id;
											$this->access_token = $_GET['access_token'];
											$this->uid = $this->get_id_access_token($this->access_token);
											$this->responses = array(
											'responses' => array(
												'message' => $this->GlobalMD->msg(1000),
												'result' => array(
													'data' => array(
														'access_token'=> $this->access_token,
														'info'=> $this->GlobalMD->info_contact($this->contact_id,$this->uid),
													),
												),
											),
										);
										}else{
											$this->responses = $this->GlobalMD->msg(2003);
										}
									}else{
										$this->responses = $this->GlobalMD->msg(2005);
									}
								}else{
									$this->responses = $this->GlobalMD->msg(2003);
								}
							}else{
								$this->responses = $this->GlobalMD->msg(2001);
							}
						}else{
							$this->responses = $this->load_error_expired_token();
						}
					}else{
						$this->responses = $this->GlobalMD->msg(2200);
					}
				}else{
					$this->responses = $this->GlobalMD->msg(2200);
				}
			}
		}
		$this->response($this->responses);
	}
	
	public function create_contact_get(){
		
	}
	
	
}
?>