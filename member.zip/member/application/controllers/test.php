<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Test extends MX_Controller {
	public $responses;
	public $token;
	public $keys;
	function __construct(){
		parent::__construct();
		$this->load->library('rest');
		$config =  array('server' => base_url());
		$this->rest->initialize($config);
		$this->load->model('global_model', 'GlobalMD');	
		$this->keys = CORE_KEY();
		$this->consumer_key = CONSUMER_KEY();
		$this->consumer_secret = CONSUMER_SECRET();
		$this->consumer_ttl = CONSUMER_TTL();
		$this->token = null;
	}
	private function install_token_to_db($param){
		try{
			$response = $this->mongo_db->insert('token', $param);
			return $response;
		}catch (Exception $e) {
            return null;
        }
	}
	public function register(){
		 $token = 'eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJrZXkiOiI5SkZrNTlUams5U2ROSjR6TjBOWkRCTmxEa1ZIenNvcnBKSm5JTXlxZmdya3l2NllyaFdlQjlhQXo2UUMiLCJpZF90b2tlbiI6IjVhYjM2ZmEyNDVmYmJlMDk0ZWEwMGI3OCIsInVpZCI6IjVhN2NlMWQ2OGQyOTYxMmZmYzNhOWQ0NSIsInBhcmFtIjp7Il9pZCI6eyIkaWQiOiI1YTdjZTFkNjhkMjk2MTJmZmMzYTlkNDUifSwibmFtZSI6IlJlc2VsbGVyIiwiY29kZSI6IlJlc2VsbGVyMDAxIiwidXNlcm5hbWUiOiJSZXNlbGxlciIsImNvbnRhY3RfZGVmYXVsdHMiOnsiJGlkIjoiNWE3YzEyNWNlMDEzNWIwZjFhMDAwMDM3In0sImNvbnRhY3Rfb3duZXIiOnsiJGlkIjoiNWE3Y2RkMzQ4ZDI5NjEyZmZjM2E5Y2Y2In0sImNvbnRhY3RfYmlsbCI6eyIkaWQiOiI1YTdjZGQ5ZDhkMjk2MTJmZmMzYTljZjcifSwiY29udGFjdF90ZWNoIjp7IiRpZCI6IjVhN2NkZGFiOGQyOTYxMmZmYzNhOWNmOCJ9LCJjb250YWN0X2FkbWluIjp7IiRpZCI6IjVhN2NkZGIyOGQyOTYxMmZmYzNhOWNmOSJ9LCJjb250YWN0X21vZGVyYXRvciI6eyIkaWQiOiI1YTdjZGRiNjhkMjk2MTJmZmMzYTljZmEifSwiYmFsYW5jZXIiOjk5OTk5OTk5OSwic3RhdHVzIjoxLCJpZF9yZWxsIjp7IiRpZCI6IjVhN2MxMjVjZTAxMzViMGYxYTAwMDAzOCJ9fSwiZXhwaXJlc19pbiI6IjIwMTgtMDMtMjJUMTc6NTY6MDIrMDcwMCIsInR0bCI6NzIwMH0.DIr8wq6mlryw3JUumVkDGYGe2I8UUpI8wt4X14Ro3KY';
		$param = array('access_token' => $token,'param' => json_encode(
			array('full_name' => 'handesk',
					'email' => 'handeskdotvn@gmail.com',
					'password' => '1234fF!@#$',
					'id_rell' => '5a7c125ce0135b0f1a000038',)),);
		$response = $this->rest->post('client/add',$param);
		echo "<pre>";
			var_dump($response);
		echo "</pre>";
	}
	public function index(){
		$param = array(
			'param' => json_encode(array(
				'username' => 'Reseller',
				'password' => '123123fF',
			)),
		);
		$response = $this->rest->get('token/create',$param);
		$token = $response->responses->result->data->access_token->results;
		$param_check = array(
			'param' => json_encode(array(
				'access_token' => $token,
			)),
		);
		$response_check = $this->rest->get('token/check',$param_check);
			echo "<pre>";
				var_dump($response_check);
			echo "</pre>";
	}

	
}
?>