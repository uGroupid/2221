<?php
class visa_model extends CI_Model{ 
	function __construct(){
		parent::__construct();	
		
	}

	public function load_log($data){
		$this->mongo_db->insert('log_api',$data);
	}
	private function responses_msg($code=00){
		$code = "$code";
		$response =  $this->mongo_db->select('code,message')->where(array('code' => "$code"))->get('conf_responses');
		if(!empty($response)){ return $response[0]; }else{ return $response; }
	}
	
	public function msg($code=00){
		$msg = $this->responses_msg($code);
		if(!empty($msg)){ return $msg; }else{ return  $this->responses_msg(2000); }
	}
	public function add($x){
		try{
			$array = array(
				'sesion_id' => $x->sesion_id,
				'ip_address' => $x->ip_address,
				'user_data' => $x->user_data,
				'user_agent' => $x->user_agent,
				'last_activity' => $x->last_activity,
				'time_buy'=> $x->time_buy,
				'type_card_visa'=> $x->type_card_visa,
				'card_value'=> $x->card_value,
				'fullname_veryfile'=> $x->fullname_veryfile,
				'email_veryfile'=> $x->email_veryfile,
				'phone_veryfile'=> $x->phone_veryfile,
				'addr_veryfile'=> $x->addr_veryfile,
				'password_veryfile'=> $x->password_veryfile,
				'cmd'=> $x->cmd,
				'status'=> 1,
			);
			$response = $this->mongo_db->insert('visa_online',$array);
			return $response;
		}catch (Exception $e) { return $this->msg();}
	}

	

	

}
?>