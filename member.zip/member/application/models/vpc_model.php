<?php
class Vpc_model extends CI_Model{ 
	function __construct(){
		parent::__construct();	
		$this->key = CONSUMER_KEY();
	}
	
	public function addPrimary($uid,$x){
		try{
			return $this->validate_contact($uid,$x);
		}catch (Exception $e) { return $this->msg(2000);}
	}
	public function load_log($data){
		$this->mongo_db->insert('log_api',$data);
	}
	private function responses_msg($code=00){
		$code = "$code";
		$response =  $this->mongo_db->select('code,message')->where(array('code' => "$code"))->get('conf_responses');
		if(!empty($response)){ return $response[0]; }else{ return $response; }
	}
	
	public function msg($code=00){
		$msg = $this->responses_msg($code);
		if(!empty($msg)){ return $msg; }else{ return  $this->responses_msg(2000); }
	}
	private function install_contact_db($array){
		try{
			if(isset($array)){ if(!empty($array)){				
				try{ 
				$response = $this->mongo_db->insert('contacts',$array);
					return $response;
				}catch (Exception $e) { return false; }
			}else{ return false; } }else{ return false;}
		}catch (Exception $e) { return false;}
	}

	public function LoadListInfoVPC($u){
		try{
			if(isset($u)){
				if(!empty($u)){
					try{
						$r = $this->mongo_db->where(array('uid'=>  new \MongoId($u)))->get('vpc');
						return $r;
					}catch (Exception $e) { return false; }
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	public function getListInfoVPC($u){
		try{
			if(isset($u)){
				if(!empty($u)){
					try{
						$r = $this->mongo_db->where(array('uid'=>  new \MongoId($u)))->get('vpc');
						$n_array = false;
						if(isset($r[0]['server_id'])){
							$sid = (string)$r[0]['server_id'];
							if($sid){
								$n_array = array(
									'r' => $sid,
									'key' => $this->key,
									's' => $this->load_server_info($sid),
									
								);
							}
						}
						return $n_array;
					}catch (Exception $e) { return false; }
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	
	private function load_server_info($s){
		if(isset($s)){
			if(!empty($s)){
				try{
					$r = $this->mongo_db->where(array('_id'=>  new \MongoId($s)))->get('vpc_server');
					   return $r;
				}catch (Exception $e) { return false; }
			}else{ return false; }
		}else{ return false;}
	}
	

}
?>