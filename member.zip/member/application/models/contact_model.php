<?php
class Contact_model extends CI_Model{ 
	function __construct(){
		parent::__construct();	
		
	}
	
	public function addPrimary($uid,$x){
		try{
			return $this->validate_contact($uid,$x);
		}catch (Exception $e) { return $this->msg(2000);}
	}
	public function load_log($data){
		$this->mongo_db->insert('log_api',$data);
	}
	private function responses_msg($code=00){
		$code = "$code";
		$response =  $this->mongo_db->select('code,message')->where(array('code' => "$code"))->get('conf_responses');
		if(!empty($response)){ return $response[0]; }else{ return $response; }
	}
	
	public function msg($code=00){
		$msg = $this->responses_msg($code);
		if(!empty($msg)){ return $msg; }else{ return  $this->responses_msg(2000); }
	}
	private function install_contact_db($array){
		try{
			if(isset($array)){ if(!empty($array)){				
				try{ 
				$response = $this->mongo_db->insert('contacts',$array);
					return $response;
				}catch (Exception $e) { return false; }
			}else{ return false; } }else{ return false;}
		}catch (Exception $e) { return false;}
	}
	private function validate_contact($uid,$x){
		$title_contact =  $x->title_contact;
		$array_contact_add = array(
			"id_users" => new \MongoId($uid),
			"roid" => $uid.time(),
			"title_contact" =>  $title_contact,
			"postal" =>  $x->title_contact,
			"name" =>  $x->title_name . ' ' .$x->last_name . ' ' .$x->middle_name.' '.$x->first_name,
			"title_name" =>  $x->title_name,
			"middle_name" =>  $x->middle_name,
			"first_name" =>  $x->first_name,
			"last_name" =>  $x->last_name,
			"extends" =>  $x->country,
			"addr" =>  $x->address,
			"city" =>  $x->city,
			"district" => $x->district,
			"province" =>  $x->district,
			"postcode" =>  $x->postcode,
			"country" =>  $x->country,
			"voice" =>  $x->mobile_phone,
			"home_phone" =>  $x->home_phone,
			"mobile_phone" =>  $x->mobile_phone,
			"work_phone" =>  $x->work_phone,
			"type_contact_primary" =>  $x->type_contact_primary,
			"fax" => null,
			"position" =>  $x->position,
			"company_unit" =>  $x->company_unit,
			"company" =>  $x->company,
			"passport" =>  $x->passport,
			"birth" =>  $x->birthday,
			"email" =>  $x->email,
			"authInfo" =>  core_random_auth(),
			"date_create" =>   date("Y-m-d H:s:i",time()),
			"date_update" =>  date("Y-m-d H:s:i",time()),
			"date_transfer" =>  date("Y-m-d H:s:i",time()),
			"flag" => 0,
			"status" => 1
		);
		$type_contact_primary = $x->type_contact_primary;
		if($type_contact_primary == 'Owner'){ $field = 'contact_owner'; }
		if($type_contact_primary == 'Billing'){ $field = 'contact_bill'; }
		if($type_contact_primary == 'Technical'){ $field = 'contact_tech'; }
		if($type_contact_primary == 'Admin'){ $field = 'contact_admin'; }
		if($type_contact_primary == 'Manager'){ $field = 'contact_moderator'; }
		$id_contact = $this->install_contact_db($array_contact_add);
		
		if($id_contact){
			$params_update = array( $field =>  $id_contact, );
				return $this->update_contact_to_user($uid,$params_update);
		}else{ return false; }
	}
	public function PrivateRemoveContactID($c){
		return $this->mongo_db->where(array('_id'=>  new \MongoId($c)))->delete('contacts');
	}
	
	public function InfoContactID($c){
		try{
			if(isset($c)){
				if(!empty($c)){
					try{
						$response = $this->mongo_db->where(array('_id'=>  new \MongoId($c)))->get('contacts');
						
						return $response;
						
					}catch (Exception $e) { return false; }
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	public function getInfoContactClients($uid){
		try{
			if(isset($uid)){
				if(!empty($uid)){
					try{
						$response = $this->mongo_db->select(array('contact_owner','contact_bill','contact_tech','contact_admin','contact_moderator'))->where(array('_id'=>  new \MongoId($uid)))->get('users');
						return $response;
					}catch (Exception $e) { return false; }
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	public function update_contact_to_user($uid,$array){
		try{
			if(isset($uid)){
				if(!empty($uid)){
					try{
						$update =	$this->mongo_db->where(array('_id'=>  new \MongoId($uid)))->set($array)->update('users');
						return $update;
					}catch (Exception $e) { return false; }
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}

}
?>