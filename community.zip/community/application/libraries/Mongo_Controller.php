<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Mongo_Controller extends MY_Controller {
	public $connect;
	public $collection;
	public function __construct()
	{
		parent::__construct();
		$primary = '192.168.1.221';
		$secondary = '192.168.1.223';
		$username = "ureg";
		$password = "112233fF";
		$database = "atp";
		$port = "27017";
		try{
			$this->connect =  new MongoClient("mongodb://".$primary.":27017/".$database);
			$this->db = $this->connect->atp;
		}catch(MongoConnectionException $e){
			$this->connect =  new MongoClient("mongodb://".$secondary.":27017/".$database);
			$this->db = $this->connect->atp;
		}
	}
	public function PhoneByLike($value){
		$vnphone = $this->db->vnphone;
		return $vnphone->find(array('phone','/'.$value.'/'));
	}
	public function ConvertPhoneToUID($phone){
		$vnphone = $this->db->vnphone;
		return  $vnphone->findOne(array('phone' => $phone));
	}
	public function convertUidToPhone($string){
		$vnphone = $this->db->vnphone;
		$uid = $this->convert_string_to_array_textarea($string);
		return  $vnphone->findOne(array('uid' => $uid));
	}
	private function convert_string_to_array_textarea($string){
		$string = preg_replace("/[^0-9]/", "",$string);
		$string = trim($string);
		return $string;
	}
}