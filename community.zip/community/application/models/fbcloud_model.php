<?php
class Fbcloud_model extends CI_Model{ 
	
	function __construct(){
		parent::__construct();	
		$this->uid = null;
	}

	public function load_log($data){
		$this->mongo_db->insert('log_api',$data);
	}
	private function responses_msg($code=00){
		$code = "$code";
		$response =  $this->mongo_db->select('code,message')->where(array('code' => "$code"))->get('conf_responses');
		if(!empty($response)){ return $response[0]; }else{ return $response; }
	}
	
	public function msg($code=00){
		$msg = $this->responses_msg($code);
		if(!empty($msg)){ return $msg; }else{ return  $this->responses_msg(2000); }
	}
	public function Add($x){
		try{
			$param = array(
				'uid' =>  new \MongoId($x->uid),
				'fb_token' => $x->fb_token,
				'fb_id' => $x->fb_id,
				'fb_name' => $x->fb_name,
				'status' => 1,
			);
			$result_token_add = $this->check_token_add($x->uid);
			if($result_token_add){
				$nem = false;
				foreach($result_token_add as $value){
					$uid_update = $value["_id"]->{'$id'};
					try{
						$clients_update_old = $this->mongo_db->where(array('_id'=>  new \MongoId($uid_update),'status'=> 1,))->set('status', 2)->update('users_community');
						$nem = true;
					}catch (Exception $e) {  $nem =  false; }
				}
				return $nem;
			}else{ 
				return $this->mongo_db->insert('users_community',$param);
			}		
		}catch (Exception $e) { return false; }
	}
	
	private function check_token_add($uid){
		try{
			$clients =	$this->mongo_db->where(array('uid'=>  new \MongoId($uid),'status'=> 1,))->get('users_community');
			if($clients){
				return $clients; 
			}else{ return false; }		
		}catch (Exception $e) { return false; }
	}
	public function Check($x){
		if(!empty($x->uid)){
			try{
				$uid = $x->uid;
				$clients =	$this->mongo_db->where(array('uid'=>  new \MongoId($uid), 'status'=> 1,))->get('users_community');
				if($clients){
					if(!empty($clients[0])){ return true; }else{ return false; }
				}else{ return false; }		
			}catch (Exception $e) { return false; }
		}else{ return false; }
	}
	public function Info($x){
		if(!empty($x->uid)){
			try{
				$uid = $x->uid;
				$clients =	$this->mongo_db->where(array('uid'=>  new \MongoId($uid), 'status'=> 1,))->get('users_community');
				if($clients){
					return $clients;
				}else{ return false; }		
			}catch (Exception $e) { return false; }
			return $x->uid;	
		}else{ return false; }
	}
	

	

}
?>