<?php

class Core_model extends CI_Model{
	function __construct(){
			parent::__construct();	
	}
	public function query_update_profile_account($x){
		if(isset($x['uid']) || !empty($x['uid']) || isset($x['profile']) || !empty($x['profile'])){
		  try{
			  $profile = $x['profile'];
			  $uid = $x['uid'];
			  $update_profile =	$this->mongo_db->where(array('_id'=>  new \MongoId($uid)))->set($profile)->update('users');
			  if($update_profile==true){ return true; }else{ return false;}
			}catch (Exception $e) { return false; }
		}else{ return false;}
	}
	
	public function query_info_uid_clients($uid){
		try{
			if(isset($uid)){
				if(!empty($uid)){
					try{
						$clients =	$this->mongo_db->where(array('_id'=>  new \MongoId($uid)))->get('users');
						if(isset($clients)){
							if(!empty($clients[0])){
								return $clients[0];
							}else{ return false; }
						}else{ return false; }		
					}catch (Exception $e) {
						return false;
					}
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	public function query_update_activation($x){
		try{
			if(isset($x->uid)){
				if(!empty($x->uid)){
					try{
						$update_zone =	$this->mongo_db->where(array('_id'=>  new \MongoId($x->uid)))->set(array('status'=>1,'recommend'=>2))->update('users');
						return $update_zone;
					}catch (Exception $e) {
						return false;
					}
				}else{ return false; }
			}else{ return false;}
		}catch (Exception $e) { return false;}
	}
	public function query_client_creation($x=null){
		try{
			if(isset($x)){
				if(!empty($x)){
					if(isset($x->full_name) || isset($x->email) || isset($x->password) || isset($x->id_rell)){
						if(!empty($x->full_name) || !empty($x->email) || !empty($x->password) || !empty($x->id_rell)){
							$params_clients_add_news = array(
								'name' => $x->full_name, 
								'code' => null, 
								'username' => $x->email,
								'email' => $x->email,
								'passwords' => md5($x->password),
								'contact_defaults' => null, 
								'contact_owner' => null,
								'contact_bill' => null,
								'contact_tech' => null,
								'contact_admin' => null,
								'contact_moderator' => null,
								'role' => (int)2, 
								'balancer' => (int)0, 
								'date_create' => date("Y-m-d h:i:s",time()), 
								'date_update' => date("Y-m-d h:i:s",time()), 
								'status'=> (int)2,
								'id_rell'=> new \MongoId($x->id_rell),
							);
							try{
							$id_insert = $this->mongo_db->insert('users',$params_clients_add_news);
								if(!empty($id_insert)){
									$params_log = array(
										$params_clients_add_news,
										$id_insert,
										$this->msg(3003),
									);
									$this->log_action($params_log);
									return $this->msg(3003);
								}else{ 
									$params_log = array(
										$params_clients_add_news,
										$this->msg(3004),
									);
									$this->log_action($params_log);
									return $this->msg(3004); 
								}
							}catch (Exception $e) {
								$params_log = array(
									$x,
									$this->msg(3004),
								);
								$this->log_action($params_log);
								return $this->msg(3004);
								
							}
						}else{ 
							$params_log = array(
								$this->msg(3004),
							);
							$this->log_action($params_log);
							return $this->msg(3004);
						}
					}else{ 
						$params_log = array(
								$this->msg(3004),
							);
							$this->log_action($params_log);
							return $this->msg(3004);
					}
				}else{ 
				$params_log = array(
					$this->msg(3004),
				);
				$this->log_action($params_log);
				return $this->msg(3004);
				}
			}else{ 
				$params_log = array(
					$this->msg(3004),
				);
				$this->log_action($params_log);
				return $this->msg(3004);
			}
		}catch (Exception $e) {
			$params_log = array(
					$this->msg(3004),
				);
				$this->log_action($params_log);
				return $this->msg(3004);
		}
	}
	public function log_action($params){
		$params_log = array(
			$this->session->all_userdata(),$params
		);
		$this->mongo_db->insert('logs_api',$params_log);
	}
	public function query_check_client($email=null){
		try{
			if(isset($email)){
				if(!empty($email)){
					$response = $this->mongo_db->get_where('users',array('username'=>$email));
					if(!empty($response)){return $this->msg(3002);}else{return $this->msg(3001);}
				}
			}else{
				return $this->msg(3002);
			}
		}catch (Exception $e) {return $this->msg(3002);}
	}
	
	private function responses_msg($code=00){
		$code = "$code";
		$response =  $this->mongo_db->select('code,message')->where(array('code' => "$code"))->get('conf_responses');
		if(!empty($response)){
			return $response[0];
		}else{
			return $response;
		}
		
	}
	
	public function msg($code=00){
		$msg = $this->responses_msg($code);
		if(!empty($msg)){
			return $msg;
		}else{
			return  $this->responses_msg(2000);
		}
	}
	
/////////////////// End Noi dung ////////////

}
?>