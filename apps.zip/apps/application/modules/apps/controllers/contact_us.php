<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Contact_us extends REST_Controller {
	public $response;
	function __construct(){
		parent::__construct();
		$this->response = array('msg' => 'Error Send, Pl? Try Again', );
		$this->full_name = null;
		$this->phone = null;
		$this->email = null;
		$this->subject = null;
		$this->message = null;
	}
	public function index_get(){
		if(isset($_GET['email']) || !empty($_GET['email'])){
			$checkEmail = Appscore::isValidEmailName($_GET['email']);
			if($checkEmail==true){
				if(isset($_GET['subject']) || !empty($_GET['subject'])){
					if(isset($_GET['message']) || !empty($_GET['message'])){
						
						if(!empty($_GET['full_name'])){ $this->full_name = $_GET['full_name']; }
						if(!empty($_GET['email'])){ $this->email = $_GET['email']; }
						if(!empty($_GET['phone'])){ $this->phone = $_GET['phone']; }
						if(!empty($_GET['message'])){ $this->message = $_GET['message']; }
						$this->subject = 'Câu hỏi khách hàng? Trên uDNS là '.$_GET['subject'];
						$this->body = 'Khách Hàng có Email ' . $this->email . ', Có nội dung hỏi bạn là: '. $this->message;
						$param_email_contact_us = array(
							'email_from' => $this->email,
							'full_name' => $this->full_name,
							'phone_to' => $this->phone,
							'email_to' => 'ugroupid@gmail.com',
							'subject' => $this->subject,
							'body' => $this->body,
							'time_post' => date("Y-m-d H:s:i",time()),
							'status' => 1,
							'time_send' => null,
						);
						$this->response = Appscore::method_contact_news($param_email_contact_us);
					}else{ $this->response = array('msg' => 'Error Syntax message, Pl? enter message', ); }
				}else{ $this->response = array('msg' => 'Error Syntax subject, Pl? enter subject', ); }
			}else{ $this->response = array('msg' => 'Error Syntax Email, Pl? enter email', ); }
		}else{ $this->response = array('msg' => 'Error Syntax Email, Pl? enter email', ); }
		$this->response($this->response);
	}
	
///---End Class Apps REST---///
}
////------Start Class Core Apps-------////	
class Appscore extends MY_Controller{
	public $response;
	function __construct(){
		parent::__construct();
		$this->response = null;
	}

	public function isValidEmailName($email) {
		  return (preg_match('/^(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\]))$/iD', $email));
	}
	
	public  function method_contact_news($params){
		$this->response = array('msg' => 'Not Send Contact Us, Pl? Try Again', ); 
		try{
			$monitor_setup = $this->mongo_db->insert('ureg_email_monitor', $params);
			if(isset($monitor_setup)){
				if($monitor_setup==true){ 
					$this->response = array('msg' => 'Your message has been sent successfully. We will answer your questions as soon as possible, We thank you for using the service at uGroup.', );
					return $this->response; 
				}else{ return $this->response; }
			}else{return $this->response;}
		}catch (Exception $e) { return $this->response; }
	}
///---End Class Apps---///	
}
?>