<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
class Core extends REST_Controller {
	function __construct(){
		parent::__construct();
		// $this->load->model('reset_model','ResetMD');
		$this->response = array();
	}
	public function dnsAccount_get(){
		$this->response = array(
			'result' => Appscore:GetDNSAccountAll(),
		);
		$this->response($this->response);
	}

	
	
}


class Appscore extends MY_Controller{
	function __construct(){
		parent::__construct();
		$this->response = null;
	}
	public function GetDNSAccountAll(){
		try{
			$this->response =	$this->mongo_db->get('ureg_users');
			return $this->response;
		}catch (Exception $e) {
			return false;
		}
	}
}

